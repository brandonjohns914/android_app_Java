package com.example.lab05;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity
{
//connection to app
    private Button login;
    private EditText userName;
    private EditText password;
    private int numAttempts = 3;
    private TextView attempts;
    private CheckBox show;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
            // connecting button
        login = findViewById(R.id.button);
        /// connecting ID
        userName = findViewById(R.id.ID);
        //connecting password
        password = findViewById(R.id.Password);
        // connection attempts
        attempts = findViewById(R.id.Attempt);

        // connecting show password
        show = findViewById(R.id.show);

        // sets up show if its clicked
        show.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked)
            {
                if (isChecked) {
                    // show password
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    // hide password
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });
            // log on button
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CorrectUserPass(userName.getText().toString(), password.getText().toString());
            }
        });

    }

        /// checks username and password
    private void CorrectUserPass(String userName, String password)
    {
        String UserID = "011994385";
        String UserPass = "CMPE#137";
        if(userName.matches(UserID) && password.matches(UserPass) )
        {//login toaast
            Toast loginToast = Toast.makeText(getApplicationContext(), "Welcome 011994385", Toast.LENGTH_LONG);
            loginToast.show();
            attempts.setText("logging in");
            Intent loggedIn = new Intent(Login.this, MainActivity.class);
            startActivity(loggedIn);

        }
        else
            {
            numAttempts--;
            if (numAttempts == 3)
            { }
            if (userName.matches(UserID))
            {/// password toast
                Toast passwordToast = Toast.makeText(getApplicationContext(), Password(password), Toast.LENGTH_LONG);
                passwordToast.show();

                attempts.setText( " Attempts : " + numAttempts + " of 3");

            }else if(password.matches(UserPass))
            {//username toast
                Toast usernameToast = Toast.makeText(getApplicationContext(), UserName(userName), Toast.LENGTH_LONG);
                usernameToast.show();
                attempts.setText( " Attempts : " + numAttempts + " of 3");

            }
            else
                {//usernamepass toast
                Toast userpassToast = Toast.makeText(getApplicationContext(), "Wrong ID and/or Password", Toast.LENGTH_LONG);
                userpassToast.show();

                attempts.setText( " Attempts : " + numAttempts + " of 3");
            }
        }

    }
/// checks pass
    private String Password(String password){
        if (password.matches("cmpe#137")){
            return "something wrong with typed password";
        }else {
            return "Wrong Password";
        }

    }
/// checks id
    private String UserName(String userName){

        if(!android.text.TextUtils.isDigitsOnly(userName)){
            return "ID must be digits";
        } else {
            return "Wrong UserName";
        }
    }

}